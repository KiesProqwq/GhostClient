package cn.KiesPro.module.render;

import cn.KiesPro.module.Category;
import cn.KiesPro.module.Module;

/*
 * MixinEntityRenderer
 */
public class ViewClip extends Module {

	public ViewClip() {
		super("ViewClip", "看过了石头", Category.RENDER);
	}
	
}
