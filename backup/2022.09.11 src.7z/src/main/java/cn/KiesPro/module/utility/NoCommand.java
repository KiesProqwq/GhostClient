package cn.KiesPro.module.utility;

import cn.KiesPro.module.Category;
import cn.KiesPro.module.Module;

public class NoCommand extends Module {

	public NoCommand() {
		super("NoCommand", "Bypass some server register.", Category.Utility);
	}

}
