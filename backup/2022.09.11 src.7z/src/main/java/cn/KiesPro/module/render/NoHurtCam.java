package cn.KiesPro.module.render;

import cn.KiesPro.module.Category;
import cn.KiesPro.module.Module;

/*
 * MixinEntityRenderer.java
 */
public class NoHurtCam extends Module {

	public NoHurtCam() {
		super("NoHurtCam", "Removes the hurt animation", Category.RENDER);
	}
	
}
