package cn.KiesPro.module;

public enum Category {
	COMBAT,
	MOVEMENT,
	PLAYER,
	RENDER,
	Utility,
	MISC
}
