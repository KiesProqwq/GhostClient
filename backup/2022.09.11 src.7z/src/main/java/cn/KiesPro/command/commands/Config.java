package cn.KiesPro.command.commands;

import cn.KiesPro.Client;
import cn.KiesPro.command.Command;

public class Config extends Command {

	public Config(String name, String description, String syntax, String[] aliases) {
		super(name, description, syntax, aliases);
		// TODO 自动生成的构造函数存根
	}

	@Override
	public void onCommand(String[] args, String command) {
		// TODO 自动生成的方法存根
		
	}
}