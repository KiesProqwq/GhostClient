package cn.KiesPro.file;

public class ClickGuiFile {
	
	public ClickGuiFile() {

	}
	
    public void saveClickGui() {

    }
    
	private void load() {
		
	}
}
