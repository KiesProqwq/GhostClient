package cn.KiesPro.event.events;

import cn.KiesPro.event.eventapi.events.Event;

/*
 * @see MixinEntityPlayerSP.java
 */
public class EventUpdate implements Event {

}
