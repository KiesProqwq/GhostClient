package cn.KiesPro.event.events;

import cn.KiesPro.event.eventapi.events.Event;

public class EventTick implements Event {

}
